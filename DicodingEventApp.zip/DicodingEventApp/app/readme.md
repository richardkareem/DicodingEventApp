# Dicoding Event App
Belajar Android Native menggunakan Kotlin, aplikasi sederhana menggunakan Bottom Navigation dan Retrofit untuk fetch API, menggunakan API yang telah disediakan oleh Dicoding
## Features
- Melihat Event Dicoding upcoming dan finished event
- Search event

Rilekin aja jangan serius serius,, cuman belajar aja kok ini leee
Feel free kalo mau ngajarin kita belajar bareng bareng lee
## License

MIT

**Free EAK, !**